package rpg;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Human Player Auto-grader 
 * 
 * Methods auto-graded:
 *  - validateMove()
 *  - selectTarget()
 *  - determineAttackerStrength()
 *  - resetTemporaryDefense()
 *  - isKnockedOut()
 * 
 * Methods requiring manual grading (during gameplay):
 *  - humanTurn()
 *  - moveUnit()
 *
 * Methods provided in starter code and not tested
 *  - getFalia/Ama/Erom()
 *  - generateLevel()
 *  - generateJob()
 *  
 */

public class HumanPlayerTest {

    private HumanPlayer humanPlayer;

    @BeforeEach
    public void setUp() {
        // Initialize a new HumanPlayer before each test
        humanPlayer = new HumanPlayer();
    }
       
    /**
     * Test the validation of moves.
     * Ensures that valid moves return the expected results.
     */
    @Test
    public void testValidateMove() {
        // Test case 1: Valid attack move
        String move = "a";
        String result = humanPlayer.validateMove(move);
        assertEquals("attack", result);

        // Test case 2: Valid block move
        move = "b";
        result = humanPlayer.validateMove(move);
        assertEquals("block", result);

        // Test case 3: Invalid move
        move = "invalid";
        result = humanPlayer.validateMove(move);
        assertNull(result);
    }
    
    /**
     * Test the target selection functionality.
     * Ensures that the correct target is selected or null is returned for invalid targets.
     */
    @Test
    public void testSelectTarget() {
        // Test case 1: Target exists in the computer's units
        ComputerPlayer computer = new ComputerPlayer();
        computer.criati.setHp(100);
        computer.ledde.setHp(0);
        computer.tyllion.setHp(1);
        
        Unit selectedTarget = humanPlayer.selectTarget("Criati", computer);
        assertEquals(computer.criati, selectedTarget);

        // Test case 2: Target does not exist in the computer's units
        Unit selectedNonExistentTarget = humanPlayer.selectTarget("Null", computer);
        assertNull(selectedNonExistentTarget);

        // Test case 3: Target hp is 0  
        Unit selectedZeroHpTarget = humanPlayer.selectTarget("Ledde", computer);
        assertNull(selectedZeroHpTarget);

        // Test case 4: Target hp is 1
        Unit selectedOneHpTarget = humanPlayer.selectTarget("Tyllion", computer);
        assertEquals(computer.tyllion, selectedOneHpTarget);
    }
    
    /**
     * Test the reset of temporary defense values.
     * Ensures that all units have their temporary defense reset to 0.
     */
    @Test
    public void testResetTemporaryDefense() {
        // Set initial defensive buff values for all units
        humanPlayer.getFalia().setTemporaryDefense(10);
        humanPlayer.getErom().setTemporaryDefense(5);
        humanPlayer.getAma().setTemporaryDefense(8);

        // Reset defensive buff
        humanPlayer.resetTemporaryDefense();

        // Check if all units have their defensive buff reset to 0
        assertEquals(0, humanPlayer.getFalia().getTemporaryDefense());
        assertEquals(0, humanPlayer.getErom().getTemporaryDefense());
        assertEquals(0, humanPlayer.getAma().getTemporaryDefense());

        // Test case 2: Defensive buff already set to 0
        humanPlayer.falia.setTemporaryDefense(0);
        humanPlayer.erom.setTemporaryDefense(0);
        humanPlayer.ama.setTemporaryDefense(0);

        // Reset defensive buff
        humanPlayer.resetTemporaryDefense();

        // Check if all units still have their defensive buff set to 0
        assertEquals(0, humanPlayer.falia.getTemporaryDefense());
        assertEquals(0, humanPlayer.erom.getTemporaryDefense());
        assertEquals(0, humanPlayer.ama.getTemporaryDefense());    
        
        // Test case 3: Set initial defensive buff values for some units
        humanPlayer.falia.setTemporaryDefense(0);
        humanPlayer.erom.setTemporaryDefense(5);
        humanPlayer.ama.setTemporaryDefense(0);

        // Reset defensive buff
        humanPlayer.resetTemporaryDefense();

        // Check if only the units with defensive buff have their values reset to 0
        assertEquals(0, humanPlayer.falia.getTemporaryDefense());
        assertEquals(0, humanPlayer.ama.getTemporaryDefense());
        assertEquals(0, humanPlayer.erom.getTemporaryDefense());
    }
    
    /**
     * Test if any units are knocked out.
     * Verifies the knocked-out status of the player's units.
     */
    @Test
    public void testIsKnockedOut() {
        // Test case 1: No units are KO'd initially and returns false
        humanPlayer.getFalia().setHp(100);
        humanPlayer.getErom().setHp(100);
        humanPlayer.getAma().setHp(100);
        assertFalse(humanPlayer.isKnockedOut());

        // Test case 2: Set one unit as KO'd and check if it returns true
        humanPlayer.getFalia().setHp(0);
        assertFalse(humanPlayer.isKnockedOut());

        // Test case 3: Set all units as KO'd and check if it returns true
        humanPlayer.getErom().setHp(0);
        humanPlayer.getAma().setHp(0);
        assertTrue(humanPlayer.isKnockedOut());
        
        // Test case 4: Set one unit as not KO'd and check if it returns false
        humanPlayer.getFalia().setHp(1);
        assertFalse(humanPlayer.isKnockedOut());
    }
}
