package rpg;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * GameControl Auto-grader
 * 
 * Methods auto-graded
 * 	winner()
 * 
 * Methods requiring manual grading (during game play):
 * 	humanTurn()
 * 	computerTurn()
 *  printStatus()
 *  main()
 *  introduction()
 * 
 */


public class GameControlTest {
    private GameControl gameControl;

    @BeforeEach
    public void setUp() {
        gameControl = new GameControl();
    }

    /**
     *  There are 6 possible outcomes that are tested
     *  1. Less than 10 turns; human wins
     *  2. Less than 10 turns; computer wins
     *  3. Less than 10 turns; no winner (yet)
     *  4. 10 or more turns; human wins
     *  5. 10 or more turns; computer wins
     *  6. 10 or more turns; no winner (tie)
     */
    @Test
    public void testGetWinner() {
        // Test case 1: Human player wins - less than 10 turns
        gameControl.human.falia.setHp(100);
        gameControl.human.erom.setHp(100);
        gameControl.human.ama.setHp(100);
        gameControl.computer.criati.setHp(0);
        gameControl.computer.ledde.setHp(0);
        gameControl.computer.tyllion.setHp(0);       
      	assertEquals("human", gameControl.getWinner(4));

        // Test case 4: Human player wins - more than 10 turns
        assertEquals("human", gameControl.getWinner(10));
 
        // Test case 2: Computer player wins - less than 10 turns
        gameControl.human.falia.setHp(0);
        gameControl.human.erom.setHp(0);
        gameControl.human.ama.setHp(0);
        gameControl.computer.criati.setHp(100);
        gameControl.computer.ledde.setHp(100);
        gameControl.computer.tyllion.setHp(100);       
      	assertEquals("computer", gameControl.getWinner(4));

        // Test case 5: Computer player wins - more than 10 turns
        assertEquals("computer", gameControl.getWinner(10));
        
        // Test case 3: No winner - less than 10 turns 
        gameControl.human.falia.setHp(0);
        gameControl.human.erom.setHp(0);
        gameControl.human.ama.setHp(1);
        gameControl.computer.criati.setHp(0);
        gameControl.computer.ledde.setHp(0);
        gameControl.computer.tyllion.setHp(1);  
      	assertEquals(null, gameControl.getWinner(9));
              
        // Test case 6:  No winner - 10 or more turns
      	assertEquals("tie", gameControl.getWinner(10));  
    }
        /**
     * .
     * .
     */    
    @Test
    public void testComputerTurn() {
        gameControl.human.falia.setTemporaryDefense(1);
        gameControl.human.erom.setTemporaryDefense(1);
        gameControl.human.ama.setTemporaryDefense(1);
        gameControl.takeComputerTurn();
        assertEquals(0, gameControl.human.falia.getTemporaryDefense());
    }
}