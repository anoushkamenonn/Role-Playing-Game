package rpg;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit Auto-grader 
 * 
 * Methods auto-graded:
 *  - Unit() - test constructor level assignment logic
 *  - get/setHP()
 *  - getJob()
 *  - setTemporaryDefense()
 *  - attack()
 *  - block()
 *  - receiveDamage()
 * 
 * Methods requiring manual grading (during gameplay):
 *  - printCurrentStatus()
 *  
 */
public class UnitTest {
    private Unit unit1, unit2, unit3;

    @BeforeEach
    public void setUp() {
        // Initialize three units with different job types and power levels
        unit1 = new Unit("ama", "low", "Warrior");
        unit2 = new Unit("falia", "high", "Mage");
        unit3 = new Unit("erom", "medium", "Archer");
    }

    /**
     * Test the level assignment logic for each unit.
     * Ensures levels are assigned according to the power level.
     */
    @Test
    public void testLevelAssignment() {
        // Check that unit1's level is not greater than 3
        assertTrue(3 >= unit1.getLevel());
        
        // Check that unit2's level is not less than 7
        assertTrue(7 <= unit2.getLevel());
        
        // Check that unit3's level is between 3 and 7
        assertTrue(3 <= unit3.getLevel() && 7 >= unit3.getLevel());
    }
    
    /**
     * Test the setting and getting of HP for a unit.
     * Verifies that HP can be correctly set and retrieved.
     */
    @Test
    public void testHPAssignment() {
        // Set unit1's HP to 0 and verify
        unit1.setHp(0);      
        assertEquals(0, unit1.getHp());

        // Set unit1's HP to 100 and verify
        unit1.setHp(100);
        assertEquals(100, unit1.getHp());        
    }

    /**
     * Test the job assignment logic for each unit.
     * Ensures that the job assigned during unit creation is correct.
     */
    @Test
    public void testJobAssignment() {
        // Check that unit1 is assigned the "Warrior" job
        assertEquals("Warrior", unit1.getJob());
        
        // Check that unit2 is assigned the "Mage" job
        assertEquals("Mage", unit2.getJob());
        
        // Check that unit3 is assigned the "Archer" job
        assertEquals("Archer", unit3.getJob());
    }    
    
    /**
     * Test setting the temporary defense value for a unit.
     * Ensures that the temporary defense can be correctly set and retrieved.
     */
    @Test
    public void testTemporaryDefense() {
        // Set unit2's temporary defense to 5 and verify
        unit2.setTemporaryDefense(5);
        assertEquals(5, unit2.getTemporaryDefense());
        
        // Change unit2's temporary defense to 6 and verify
        unit2.setTemporaryDefense(6);
        assertEquals(6, unit2.getTemporaryDefense());
    }
   
    /**
     * Test the attack method with varying strength types.
     * Verifies that attack damage is calculated correctly for each strength level.
     */
    @Test
    public void testAttack() {
        // Calculate attack multiplier based on unit3's level
        float attackMultiplier = (float) unit3.getLevel() / 10;
        
        // Calculate base attack value
        int attackValue = Math.round(20 * attackMultiplier);
        
        // Expected damage values for different strength levels
        int expectedStrong = (int) Math.round(attackValue / 30.0 * 50.0 * 1.2);
        int expectedSame = (int) Math.round(attackValue / 30.0 * 50.0 * 1.0);
        int expectedWeak = (int) Math.round(attackValue / 30.0 * 50.0 * 0.5);    	
        
        // Calculate expected damage for "strong" strength
        int damageStrong = unit3.attack("strong");
        assertTrue(damageStrong == expectedStrong);
        
        // Calculate expected damage for "same" strength
        int damageSame = unit3.attack("medium");
        assertTrue(damageSame == expectedSame);
        
        // Calculate expected damage for "weak" strength
        int damageWeak = unit3.attack("weak");
        assertTrue(damageWeak == expectedWeak);
    }

    /**
     * Test the block method.
     * Ensures that the temporary defense is increased correctly when blocking.
     */
    @Test
    public void testBlock() {
        // Store initial temporary defense value
        int initialDefense = unit1.getTemporaryDefense();
        
        // Block to increase temporary defense
        unit1.block();
        
        // Verify that the temporary defense is increased by 2
        assertTrue(unit1.getTemporaryDefense() == initialDefense + 2);
    }

    /**
     * Test the receiveDamage method.
     * Accounts for random calculations in damage application and evasion.
     */
    @Test
    public void testReceiveDamage() {
        // Test case 1: Evasion - unit1 should not lose HP
        unit1.setHp(100);
        unit1.setEvasion(21);
        unit1.receiveDamage(50);
        assertEquals(100, unit1.getHp());
        
        // Test case 2: No evasion - unit2 should lose HP
        unit2.setHp(100);
        unit2.setEvasion(-1);
        unit2.receiveDamage(50);
        assertTrue(100 > unit2.getHp());
    }
}
